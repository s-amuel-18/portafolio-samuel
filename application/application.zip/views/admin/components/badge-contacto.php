<?php 


  if($this->new_mesage > 0) echo "<span class='badge badge-warning right'>{$this->new_mesage}</span>";
?>