<div bgcolor="#eff3f5" text="#3b3f44" link="#68a8f6" style="background-color:#eff3f5;padding-top:0px">
    <table cellpadding="0" border="0" cellspacing="0" style="display:none">
        <tbody>
            <tr>
                <td>Cursos gratis, hasta 50% de descuento en todo EDteam, ¡y mucho más!</td>
            </tr>
        </tbody>
    </table>
    <table cellspacing="0" cellpadding="0" border="0" role="presentation" class="m_3132069292397580391nl2go-body-table" width="100%" style="background-color:#eff3f5;width:100%">
        <tbody>
            <tr>
                <td align="center" class="m_3132069292397580391r0-c">
                    <table cellspacing="0" cellpadding="0" border="0" role="presentation" width="600" class="m_3132069292397580391r1-o" style="table-layout:fixed;width:600px">
                        <tbody>
                            <tr>
                                <td valign="top" class="m_3132069292397580391r2-i" style="background-color:#ffffff">
                                    <table width="100%" cellspacing="0" cellpadding="0" border="0" role="presentation">
                                        <tbody>
                                            <tr>
                                                <td class="m_3132069292397580391r3-c" align="center">
                                                    <table cellspacing="0" cellpadding="0" border="0" role="presentation" width="100%" class="m_3132069292397580391r4-o" style="background-color:#eff3f5;background-image:url('https://ci6.googleusercontent.com/proxy/MfNB3zQtkt28jh7iSer6EN1_quTNd0kENyjbBCvJWND1CPm2jWxYZ0yO1qNZY5l-9Z98OF8m5PQflDw3cb9zsgKpRAFKIbpkSVT9wXREvns3cPte1Ag-uswB2JmJttQCAAFAvY3M=s0-d-e1-ft#https://img.mailinblue.com/2377379/images/rnb/original/619bf49135b833148b7b9b2a.jpg');background-position:top;background-repeat:no-repeat;background-size:cover;font-size:0;table-layout:fixed;width:100%">
                                                        <tbody>
                                                            <tr class="m_3132069292397580391nl2go-responsive-hide">
                                                                <td height="10" style="font-size:10px;line-height:10px">
                                                                    ­</td>
                                                            </tr>
                                                            <tr>
                                                                <td class="m_3132069292397580391r5-i">
                                                                    <table width="100%" cellspacing="0" cellpadding="0" border="0" role="presentation">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th width="100%" valign="top" class="m_3132069292397580391r6-c">
                                                                                    <table cellspacing="0" cellpadding="0" border="0" role="presentation" width="100%" class="m_3132069292397580391r7-o" style="table-layout:fixed;width:100%">
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td class="m_3132069292397580391nl2go-responsive-hide" width="10" style="font-size:0px;line-height:1px">
                                                                                                    ­ </td>
                                                                                                <td valign="top" class="m_3132069292397580391r8-i">
                                                                                                    <table width="100%" cellspacing="0" cellpadding="0" border="0" role="presentation">
                                                                                                        <tbody>
                                                                                                            <tr>
                                                                                                                <td class="m_3132069292397580391r9-c" align="center">
                                                                                                                    <table cellspacing="0" cellpadding="0" border="0" role="presentation" width="162" class="m_3132069292397580391r10-o" style="table-layout:fixed;width:162px">
                                                                                                                        <tbody>
                                                                                                                            <tr class="m_3132069292397580391nl2go-responsive-hide">
                                                                                                                                <td height="25" style="font-size:25px;line-height:25px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                            </tr>
                                                                                                                            <tr>
                                                                                                                                <td class="m_3132069292397580391r11-i" style="font-size:0px;line-height:0px">
                                                                                                                                    <a href="https://r.mail.ed.team/mk/cl/f/IOp4b3G3Cog-CBgp3vLt9khQaHlAp7kNGb05lrOQwzymtJebCFfnUuYSLR59LDIgBOSLV86Cb70fpJlGaVglXrAcF5qtR2ja5VGE2kgDR2VAxDQ28Hk26WgG-BcKyWlxQecMg5K71mscp8jL95D26Rc5JPMrQD2H_PLCGswgJGB7yXovJn043ssWtScGXJnCSSTc_0kE0cmPNJm-mJ4tP2mOzmSsNLPVQkBwB_J3Uvth1BFFp2r8WjzM_LC7oKvv635OKqWuShxY2-SCZ16SvXqQNyN-bCdKXTzr4HPfuZm0YOXRhU_x7P0-w_l_qeg-5is" style="color:#68a8f6;text-decoration:none" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://r.mail.ed.team/mk/cl/f/IOp4b3G3Cog-CBgp3vLt9khQaHlAp7kNGb05lrOQwzymtJebCFfnUuYSLR59LDIgBOSLV86Cb70fpJlGaVglXrAcF5qtR2ja5VGE2kgDR2VAxDQ28Hk26WgG-BcKyWlxQecMg5K71mscp8jL95D26Rc5JPMrQD2H_PLCGswgJGB7yXovJn043ssWtScGXJnCSSTc_0kE0cmPNJm-mJ4tP2mOzmSsNLPVQkBwB_J3Uvth1BFFp2r8WjzM_LC7oKvv635OKqWuShxY2-SCZ16SvXqQNyN-bCdKXTzr4HPfuZm0YOXRhU_x7P0-w_l_qeg-5is&amp;source=gmail&amp;ust=1638369559998000&amp;usg=AOvVaw0n3QmmHeTEb3GXJnSkjFuv">
                                                                                                                                        <img src="<?php echo base_url() ?>assets/portafolio/images/logo_white.png" width="162" border="0" style=" max-height: 100px; display: block; margin: auto; width: auto;" class="CToWUd"></a>
                                                                                                                                </td>
                                                                                                                            </tr>
                                                                                                                            <tr class="m_3132069292397580391nl2go-responsive-hide">
                                                                                                                                <td height="20" style="font-size:20px;line-height:20px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                            </tr>
                                                                                                                        </tbody>
                                                                                                                    </table>
                                                                                                                </td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td class="m_3132069292397580391r12-c" align="left">
                                                                                                                    <table cellspacing="0" cellpadding="0" border="0" role="presentation" width="100%" class="m_3132069292397580391r13-o" style="table-layout:fixed;width:100%">
                                                                                                                        <tbody>
                                                                                                                            <tr class="m_3132069292397580391nl2go-responsive-hide">
                                                                                                                                <td height="10" width="20" style="font-size:10px;line-height:10px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                                <td height="10" style="font-size:10px;line-height:10px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                                <td height="10" width="20" style="font-size:10px;line-height:10px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                            </tr>
                                                                                                                            <tr>
                                                                                                                                <td class="m_3132069292397580391nl2go-responsive-hide" width="20" style="font-size:0px;line-height:1px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                                <td align="center" valign="top" class="m_3132069292397580391r14-i m_3132069292397580391nl2go-default-textstyle" style="color:#3b3f44;font-family:arial,helvetica,sans-serif;font-size:18px;line-height:1.15;text-align:center">
                                                                                                                                    <div>
                                                                                                                                        <p style="font-family:Arial;margin:0px">
                                                                                                                                            <span style="color:#acb4b9;font-family:Arial;font-size:16px"><img data-emoji="🔥" class="an1" alt="🔥" aria-label="🔥" src="https://fonts.gstatic.com/s/e/notoemoji/14.0/1f525/32.png" loading="lazy">
                                                                                                                                                ¡Programador Back-end Developer! <img data-emoji="🔥" class="an1" alt="🔥" aria-label="🔥" src="https://fonts.gstatic.com/s/e/notoemoji/14.0/1f525/32.png" loading="lazy"></span>
                                                                                                                                        </p>
                                                                                                                                    </div>
                                                                                                                                </td>
                                                                                                                                <td class="m_3132069292397580391nl2go-responsive-hide" width="20" style="font-size:0px;line-height:1px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                            </tr>
                                                                                                                            <tr class="m_3132069292397580391nl2go-responsive-hide">
                                                                                                                                <td height="10" width="20" style="font-size:10px;line-height:10px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                                <td height="10" style="font-size:10px;line-height:10px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                                <td height="10" width="20" style="font-size:10px;line-height:10px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                            </tr>
                                                                                                                        </tbody>
                                                                                                                    </table>
                                                                                                                </td>
                                                                                                            </tr>
                                                                                                        </tbody>
                                                                                                    </table>
                                                                                                </td>
                                                                                                <td class="m_3132069292397580391nl2go-responsive-hide" width="10" style="font-size:0px;line-height:1px">
                                                                                                    ­ </td>
                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
                                                                                </th>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                            <tr class="m_3132069292397580391nl2go-responsive-hide">
                                                                <td height="10" style="font-size:10px;line-height:10px">
                                                                    ­</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="m_3132069292397580391r3-c" align="center">
                                                    <table cellspacing="0" cellpadding="0" border="0" role="presentation" width="100%" class="m_3132069292397580391r15-o" style="background-image:url('https://ci4.googleusercontent.com/proxy/PfCyJsRGrmg3SLFOje7IFIzstIUygKmAFryVDKs0BDpzVoUW9pwYFU1QrpvEQFkfB3hHLQWiJ6piNreV_hF5aF2CtBOOecqVAgH_-sSz4-5jIZoaSCDumg8DHMvEdj99hGgz=s0-d-e1-ft#https://img.mailinblue.com/2377379/images/rnb/original/619c1cee6e304c5fc744927f.');background-repeat:repeat-y;font-size:0;table-layout:fixed;width:100%">
                                                        <tbody>
                                                            <tr class="m_3132069292397580391nl2go-responsive-hide">
                                                                <td height="20" style="font-size:20px;line-height:20px">
                                                                    ­</td>
                                                            </tr>
                                                            <tr>
                                                                <td class="m_3132069292397580391r16-i">
                                                                    <table width="100%" cellspacing="0" cellpadding="0" border="0" role="presentation">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th width="100%" valign="top" class="m_3132069292397580391r6-c">
                                                                                    <table cellspacing="0" cellpadding="0" border="0" role="presentation" width="100%" class="m_3132069292397580391r7-o" style="table-layout:fixed;width:100%">
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td class="m_3132069292397580391nl2go-responsive-hide" width="10" style="font-size:0px;line-height:1px">
                                                                                                    ­ </td>
                                                                                                <td valign="top" class="m_3132069292397580391r8-i">
                                                                                                    <table width="100%" cellspacing="0" cellpadding="0" border="0" role="presentation">
                                                                                                        <tbody>
                                                                                                            <tr>
                                                                                                                <td class="m_3132069292397580391r3-c" align="center">
                                                                                                                    <table cellspacing="0" cellpadding="0" border="0" role="presentation" width="522" class="m_3132069292397580391r17-o" style="border-collapse:separate;border-radius:0px;table-layout:fixed;width:522px">
                                                                                                                        <tbody>
                                                                                                                            <tr>
                                                                                                                                <td class="m_3132069292397580391r18-i" style="border-radius:0px;font-size:0px;line-height:0px;padding-bottom:0px;padding-left:7px;padding-right:7px;padding-top:0px">
                                                                                                                                    <a href="https://r.mail.ed.team/mk/cl/f/Ws-GB0nGhXCdllP9hJ3pXjx92gGAgPg9Tl3__r6S5oFb7KX5QmP0ac_9VDyRyT0FdLnFnKXnyAEWvZUj9C9OK0NXLTCDxIu3gOGP-Vxoiy8HaV9Y6aF0f0THHAthz4qq_Lm0Pu0zzygDvcHrstj6DNtuMxOXIqgWd8ecbjxwQl8-sEKthZq7xEkHzj2IoJyqj0CvgZn-pnbs_-HHq1aaMTK61dMM3lFPZzdtfgIcTab9js1BFtk0Cpky3hm_oJugV2hZCAspWTIswbV9hLZIpRnqfjzXQ0YylV-J0x0SgjKov5-yVWa_daWMrYxuFukpE1SxesL10qKh" style="color:#68a8f6;text-decoration:none" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://r.mail.ed.team/mk/cl/f/Ws-GB0nGhXCdllP9hJ3pXjx92gGAgPg9Tl3__r6S5oFb7KX5QmP0ac_9VDyRyT0FdLnFnKXnyAEWvZUj9C9OK0NXLTCDxIu3gOGP-Vxoiy8HaV9Y6aF0f0THHAthz4qq_Lm0Pu0zzygDvcHrstj6DNtuMxOXIqgWd8ecbjxwQl8-sEKthZq7xEkHzj2IoJyqj0CvgZn-pnbs_-HHq1aaMTK61dMM3lFPZzdtfgIcTab9js1BFtk0Cpky3hm_oJugV2hZCAspWTIswbV9hLZIpRnqfjzXQ0YylV-J0x0SgjKov5-yVWa_daWMrYxuFukpE1SxesL10qKh&amp;source=gmail&amp;ust=1638369559998000&amp;usg=AOvVaw2hLx8vLEu_ZlmniW9gCruo">
                                                                                                                                        <img src="<?php echo base_url("assets/portafolio/images/banner.png") ?>" width="508" border="0" style="display:block;width:100%;border-radius:0px" class="CToWUd"></a>
                                                                                                                                </td>
                                                                                                                            </tr>
                                                                                                                        </tbody>
                                                                                                                    </table>
                                                                                                                </td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td class="m_3132069292397580391r3-c" align="left">
                                                                                                                    <table cellspacing="0" cellpadding="0" border="0" role="presentation" width="100%" class="m_3132069292397580391r17-o" style="table-layout:fixed;width:100%">
                                                                                                                        <tbody>
                                                                                                                            <tr class="m_3132069292397580391nl2go-responsive-hide">
                                                                                                                                <td height="40" width="30" style="font-size:40px;line-height:40px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                                <td height="40" style="font-size:40px;line-height:40px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                                <td height="40" width="30" style="font-size:40px;line-height:40px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                            </tr>
                                                                                                                            <tr>
                                                                                                                                <td class="m_3132069292397580391nl2go-responsive-hide" width="30" style="font-size:0px;line-height:1px">
              
                                                                                                                  ­
                                                                                                                                </td>
                                                                                                                                <td align="left" valign="top" class="m_3132069292397580391r19-i m_3132069292397580391nl2go-default-textstyle" style="color:#3b3f44;font-family:arial,helvetica,sans-serif;font-size:18px;line-height:1.15;text-align:left">
                                                                                                                                    <div>

                                                                                                                                        <p style="margin:0px">
                                                                                                                                            <span style="color:#acb4b9 !important;font-family:Arial,helvetica,sans-serif;font-size:14px">
                                                                                                                                                <span style="color: #acb4b9 !important;">

                                                                                                                                                    !Hola¡, soy un programador web con poco mas de dos años de experiencia en el desarrollo de interfaces y sistemas web, soy un apasionado por la tecnología, me especializo en lenguajes de programación como JavaScript, PHP y framewors (herramientas de desarrollo) como Laravel, Codeigniter y react.js, tengo fácil adaptación a nuevas tecnologías y me encantaría formar parte de su equipo de trabajo aportando mis conocimientos en el desarrollo de sitios web dinámicos.
                                                                                                                                                    <br>
                                                                                                                                                    <br>
                                                                                                                                                    Adjunto url de mi portafolio personal donde se refleja mas a detalle los conocimientos que manejo y los proyectos que he realizado
                                                                                                                                                </span>
                                                                                                                                            </span>

                                                                                                                                        </p>

                                                                                                                                        </p>
                                                                                                                                    </div>
                                                                                                                                </td>
                                                                                                                                <td class="m_3132069292397580391nl2go-responsive-hide" width="30" style="font-size:0px;line-height:1px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                            </tr>
                                                                                                                            <tr class="m_3132069292397580391nl2go-responsive-hide">
                                                                                                                                <td height="12" width="30" style="font-size:12px;line-height:12px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                                <td height="12" style="font-size:12px;line-height:12px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                                <td height="12" width="30" style="font-size:12px;line-height:12px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                            </tr>
                                                                                                                        </tbody>
                                                                                                                    </table>
                                                                                                                </td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td class="m_3132069292397580391r12-c" align="left">
                                                                                                                    <table cellspacing="0" cellpadding="0" border="0" role="presentation" width="100%" class="m_3132069292397580391r20-o" style="table-layout:fixed;width:100%">
                                                                                                                        <tbody>
                                                                                                                            <tr class="m_3132069292397580391nl2go-responsive-hide">
                                                                                                                                <td height="25" width="10" style="font-size:25px;line-height:25px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                                <td height="25" style="font-size:25px;line-height:25px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                                <td height="25" width="10" style="font-size:25px;line-height:25px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                            </tr>
                                                                                                                            <tr>
                                                                                                                                <td class="m_3132069292397580391nl2go-responsive-hide" width="10" style="font-size:0px;line-height:1px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                                <td align="center" valign="top" class="m_3132069292397580391r21-i m_3132069292397580391nl2go-default-textstyle" style="color:#3b3f44;font-family:arial,helvetica,sans-serif;font-size:18px;line-height:1.15;text-align:center">
                                                                                                                                </td>
                                                                                                                            </tr>
                                                                                                                        </tbody>
                                                                                                                    </table>
                                                                                                                </td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td class="m_3132069292397580391r23-c" align="center">
                                                                                                                    <table cellspacing="0" cellpadding="0" border="0" role="presentation" width="210" class="m_3132069292397580391r24-o" style="table-layout:fixed;width:210px">
                                                                                                                        <tbody>
                                                                                                                            <tr class="m_3132069292397580391nl2go-responsive-hide">
                                                                                                                                <td height="5" style="font-size:5px;line-height:5px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                            </tr>
                                                                                                                            <tr>
                                                                                                                                <td height="16" align="center" valign="top" class="m_3132069292397580391r25-i m_3132069292397580391nl2go-default-textstyle" style="color:#3b3f44;font-family:arial,helvetica,sans-serif;font-size:18px;line-height:1.15">
                                                                                                                                    <a href="<?php echo site_url() ?>" style="font-weight:bold;line-height:1.15;text-decoration:none;border-style:solid;display:inline-block;background-color:#27E278;border-color:#27E278;border-radius:5px;border-width:0px;color:#ffffff;font-family:Open Sans;font-size:14px;height:16px;padding-bottom:12px;padding-left:4px;padding-right:4px;padding-top:12px;width:202px" target="_blank">
                                                                                                                                        <p style="font-family:Arial;margin:0px">
                                                                                                                                            Portafolio
                                                                                                                                        </p>
                                                                                                                                    </a>
                                                                                                                                </td>
                                                                                                                                
                                                                                                                            </tr>
                                              <tr><td style="padding: 10px;"></td></tr>                                                                              <tr>
                                                                                                                                <td height="16" align="center" valign="top" class="m_3132069292397580391r25-i m_3132069292397580391nl2go-default-textstyle" style="color:#3b3f44;font-family:arial,helvetica,sans-serif;font-size:18px;line-height:1.15">
                                                                                                                                    <a href="<?php echo site_url("portafolio/view_curriculum") ?>" style="font-weight:bold;line-height:1.15;text-decoration:none;border-style:solid;display:inline-block;background-color: transparent;border-color:#27E278;border-radius:5px;border-width:2px;color:#27E278;font-family:Open Sans;font-size:14px;height:16px;padding-bottom:12px;padding-left:4px;padding-right:4px;padding-top:12px;width:199px" target="_blank">
                                                                                                                                        <p style="font-family:Arial;margin:0px">
                                                                                                                                            Curricullum
                                                                                                                                        </p>
                                                                                                                                    </a>
                                                                                                                                </td>
                                                                                                                                
                                                                                                                            </tr>
                                         
                                                                                                                            
                                                                                                                            <tr class="m_3132069292397580391nl2go-responsive-hide">
                                                                                                                                <td height="25" style="font-size:25px;line-height:25px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                            </tr>
                                                                                                                        </tbody>
                                                                                                                    </table>
                                                                                                                </td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td class="m_3132069292397580391r12-c" align="left">
                                                                                                                    <table cellspacing="0" cellpadding="0" border="0" role="presentation" width="100%" class="m_3132069292397580391r20-o" style="table-layout:fixed;width:100%">
                                                                                                                        <tbody>
                                                                                                                            <tr class="m_3132069292397580391nl2go-responsive-hide">
                                                                                                                                <td height="15" width="10" style="font-size:15px;line-height:15px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                                <td height="15" style="font-size:15px;line-height:15px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                                <td height="15" width="10" style="font-size:15px;line-height:15px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                            </tr>
                                                                                                                            <tr>
                                                                                                                                <td class="m_3132069292397580391nl2go-responsive-hide" width="10" style="font-size:0px;line-height:1px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                                <td align="center" valign="top" class="m_3132069292397580391r27-i m_3132069292397580391nl2go-default-textstyle" style="color:#3b3f44;font-family:arial,helvetica,sans-serif;font-size:18px;line-height:1.15;text-align:center">
                                                                                                                                    <div>
                                                                                                                                        <h4 class="m_3132069292397580391default-heading4" style="color:#1f2d3d;font-family:arial,helvetica,sans-serif;font-size:18px;margin:0px">
                                                                                                                                            <span style="color:#a0a7ac;font-family:Arial,helvetica,sans-serif">!Espero tu respuesta, comencemos este 2022 juntos¡</span>
                                                                                                                                        </h4>
                                                                                                                                    </div>
                                                                                                                                </td>
                                                                                                                                <td class="m_3132069292397580391nl2go-responsive-hide" width="10" style="font-size:0px;line-height:1px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                            </tr>
                                                                                                                            <tr class="m_3132069292397580391nl2go-responsive-hide">
                                                                                                                                <td height="20" width="10" style="font-size:20px;line-height:20px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                                <td height="20" style="font-size:20px;line-height:20px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                                <td height="20" width="10" style="font-size:20px;line-height:20px">
                                                                                                                                    ­
                                                                                                                                </td>
                                                                                                                            </tr>
                                                                                                                        </tbody>
                                                                                                                    </table>
                                                                                                                </td>
                                                                                                            </tr>
                                                                                                        </tbody>
                                                                                                    </table>
                                                                                                </td>
                                                                                                <td class="m_3132069292397580391nl2go-responsive-hide" width="10" style="font-size:0px;line-height:1px">
                                                                                                    ­ </td>
                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
                                                                                </th>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="m_3132069292397580391r3-c" align="center">
                                                    <table cellspacing="0" cellpadding="0" border="0" role="presentation" width="100%" class="m_3132069292397580391r33-o" style="background-color:#131b20;background-image:url('https://ci3.googleusercontent.com/proxy/i4yprf0ZNHZxr1r07Dwluz4Ep7OwPsgRCvG1XxxtSfCIcUnNVjDJ7L_6oJIRYVXQqtmK_ooJlw6gf1Fv3BwZOeB7fnlm1fpexOAHt8EmSzS2KWt33lkxSI_DI4dlcRsnluV0tUyl=s0-d-e1-ft#https://img.mailinblue.com/2377379/images/rnb/original/619c21185e932c28026c7a6c.jpg');font-size:0;table-layout:fixed;width:100%">
                                                        <tbody>
                                                            <tr class="m_3132069292397580391nl2go-responsive-hide">
                                                                <td height="29" width="20" style="font-size:29px;line-height:29px">
                                                                    ­ </td>
                                                                <td height="29" style="font-size:29px;line-height:29px">
                                                                    ­</td>
                                                                <td height="29" width="20" style="font-size:29px;line-height:29px">
                                                                    ­ </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="m_3132069292397580391nl2go-responsive-hide" width="20" style="font-size:0px;line-height:1px">­
                                                                </td>
                                                                <td class="m_3132069292397580391r34-i">
                                                                    <table width="100%" cellspacing="0" cellpadding="0" border="0" role="presentation">
                                                                    </table>
                                                                </td>
                                                                <td class="m_3132069292397580391nl2go-responsive-hide" width="20" style="font-size:0px;line-height:1px">­
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody>
    </table>
    <div><img width="1" height="1" src="https://ci6.googleusercontent.com/proxy/b7omHEmdPaWlwflOTVujmrk8WbQT20N4R3moJobQgfrSEbBO6CgPURRLV9U3oxIE5ymAn8c4pLKEgpZ7pjzhdUSVUxMgvUmk83uvOAhvxtKsaY4qqzQfhcFUVaK6U27zSOzUrazFSVor6sNmmIqVCc4A1Td4f0rSppBNywmYKNU8N2YltLl2gc2hVGRUzoi7bVnx5br-zDNOIaxI1Scabsc3qvtr1k_lDGyuTs825vZZXRo=s0-d-e1-ft#https://r.mail.ed.team/mk/op/ZOXWqYyNE61U9lDIplCuHNoGzneLnq2aTMbAfxXWcwuPOZLGLty0vQj2nZelIkm5Q2RMh6d8SzVa4IgpFcaCtpXd6rs6zqJ-VdVFc3nAtPmKxOWdCYsfdoTlApuySFqfaQ" class="CToWUd"></div>
    <div class="yj6qo"></div>
    <div class="adL"> </div>
</div>